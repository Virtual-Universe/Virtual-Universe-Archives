
<center><h1><font color="#858585">Welcome to</font> <?=HTML_TITLE;?></h1>
<h3><b><font color="#858585">The First WhiteCore/Virtual Universe Grid that runs on SSL<br />
While we are aware that there are still some issues to sort out we encourage you to Join us and see if you can break something ;) but please let us know how and what you broke</font></b></h3>
</center>