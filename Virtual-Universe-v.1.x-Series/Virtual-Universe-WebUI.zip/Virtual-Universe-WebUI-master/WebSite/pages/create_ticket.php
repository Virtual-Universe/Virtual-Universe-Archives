

<pre><center><h3>Open new Ticket</h3></center><hr>
<center><form action="?page=tcreate" method="POST" name="registration">
<b>Select Categorie</b><br />
<select name="categorie" class="selectpicker">
<option value="appearance">Avatar Appearance</option>
<option value="region_issues">Region Issues</option>
<option value="account_issues">Account Issues</option>
</select><br />
<b>Region: <small>(only required on Region Issues)</small></b>
<br>
<input type="text" name="region" class="make_emp_happy"><br>
<b>Subject</b>
<input type="text" name="subject" class="make_emp_happy"><br>
<b>Message</b>
<br>
<textarea id="ticketarea" name="message"></textarea>
<br>
<button type="submit" class="make_emp_happy_more">Open Ticket</button>
</form> </center>
</pre>
