<?php
$lang = array();
/*
Language: English
*/

//Globals

$lang['MENU_MAPS'] = "Maps";
$lang['MENU_REGISTER'] = "Register";
$lang['MENU_LOGIN'] = "Login";
$lang['MENU_DOWNLOAD'] = "Download";
$lang['MENU_REGIONS'] = "Regions";
$lang['MENU_LANG'] = "Choose Language";
$lang['ASK_REG'] ='No Account yet? Why not join us today? <a href="?page=register">Register</a>';
?>