<?php
$lang = array();
/*
Language: English
*/

//Globals

$lang['MENU_MAPS'] = "Karte";
$lang['MENU_REGISTER'] = "Registrieren";
$lang['MENU_LOGIN'] = "Einloggen";
$lang['MENU_DOWNLOAD'] = "Herunterladen";
$lang['MENU_REGIONS'] = "Regionen";
$lang['MENU_LANG'] = "Sprache w�hlen";
$lang['ASK_REG'] ='Noch kein Konto? Worauf noch warten? <a href="?page=register">Registrieren</a>';
?>