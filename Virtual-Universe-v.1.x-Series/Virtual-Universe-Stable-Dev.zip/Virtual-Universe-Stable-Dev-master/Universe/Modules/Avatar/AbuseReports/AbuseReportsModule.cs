/*
 * Copyright (c) Contributors, http://virtual-planets.org/
 * See CONTRIBUTORS.TXT for a full list of copyright holders.
 * For an explanation of the license of each contributor and the content it 
 * covers please see the Licenses directory.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Virtual Universe Project nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE DEVELOPERS ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

using System;
using System.Collections.Generic;
using System.IO;
using Nini.Config;
using OpenMetaverse;
using OpenMetaverse.StructuredData;
using Universe.Framework.ConsoleFramework;
using Universe.Framework.DatabaseInterfaces;
using Universe.Framework.Modules;
using Universe.Framework.PresenceInfo;
using Universe.Framework.SceneInfo;
using Universe.Framework.Servers;
using Universe.Framework.Servers.HttpServer;
using Universe.Framework.Servers.HttpServer.Implementation;
using Universe.Framework.Servers.HttpServer.Interfaces;
using Universe.Framework.Services;
using Universe.Framework.Services.ClassHelpers.Assets;
using Universe.Framework.Utilities;

namespace Universe.Modules.AbuseReports
{
    public class AbuseReportsService : IService
    {
        #region IService Members

        IAbuseReportsConnector abuseConnector;

        public void Initialize(IConfigSource config, IRegistryCore registry)
        {
        }

        public void Start(IConfigSource config, IRegistryCore registry)
        {
        }

        public void FinishedStartup()
        {
            abuseConnector = Framework.Utilities.DataManager.RequestPlugin<IAbuseReportsConnector> ();
            if (abuseConnector != null)
            {
                if (MainConsole.Instance != null)
                {
                    MainConsole.Instance.Commands.AddCommand (
                        "abuse reports",
                        "abuse reports",
                        "Display a summary of current abuse reports", 
                        HandleAbuseReports, false, true);
                }
            }
        }


        #endregion

        #region console commands
        protected void HandleAbuseReports(IScene scene, string [] cmd)
        {

            int reports;
            while (!int.TryParse (MainConsole.Instance.Prompt ("Number of reports to display: ", "7"), out reports))
                MainConsole.Instance.Info ("Bad input, must be a number > 0");

            string abuseInfo;

            abuseInfo = string.Format ("{0, -8}", "Card");
            abuseInfo += string.Format ("{0, -30}", "Category");
            abuseInfo += string.Format ("{0, -30}", "Summary");
            abuseInfo += string.Format ("{0, -20}", "Reporter");
            abuseInfo += string.Format ("{0, -20}", "Assigned");
 
            MainConsole.Instance.CleanInfo (abuseInfo);

            MainConsole.Instance.CleanInfo (
                "----------------------------------------------------------------------------------------------------");

            List<AbuseReport> abuseReports =  abuseConnector.GetAbuseReports(0, reports, true);

            foreach (AbuseReport rpt in abuseReports) {
                abuseInfo = string.Format ("{0, -8}", rpt.Number);
                abuseInfo += string.Format ("{0, -30}", rpt.Category.ToString().Substring(0,28));   
                abuseInfo += string.Format ("{0, -30}", rpt.AbuseSummary);
                abuseInfo += string.Format ("{0, -20}", rpt.ReporterName);
                abuseInfo += string.Format ("{0, -12}", rpt.AssignedTo);

                MainConsole.Instance.CleanInfo (abuseInfo);
                MainConsole.Instance.CleanInfo ("");

            }
        }

        #endregion
    }

    /// <summary>
    ///     Enables the saving of abuse reports to the database
    /// </summary>
    public class AbuseReportsModule : INonSharedRegionModule
    {
        IScene m_Scene;
        bool m_enabled;

        #region INonSharedRegionModule Members

        public void Initialize(IConfigSource source)
        {
            IConfig cnf = source.Configs["AbuseReports"];
            if (cnf != null)
                m_enabled = cnf.GetBoolean("Enabled", true);
        }

        public void AddRegion(IScene scene)
        {
            if (!m_enabled)
                return;

            m_Scene = scene;

            scene.EventManager.OnNewClient += OnNewClient;
            scene.EventManager.OnClosingClient += OnClosingClient;
            scene.EventManager.OnRegisterCaps += OnRegisterCaps;
        }

        public void RemoveRegion(IScene scene)
        {
            if (!m_enabled)
                return;


            m_Scene = null;

            scene.EventManager.OnNewClient -= OnNewClient;
            scene.EventManager.OnClosingClient -= OnClosingClient;
            //Disabled until complete
            //scene.EventManager.OnRegisterCaps -= OnRegisterCaps;
        }

        public void RegionLoaded(IScene scene)
        {
        }

        public Type ReplaceableInterface
        {
            get { return null; }
        }

        public string Name
        {
            get { return "AbuseReportsModule"; }
        }

        public void Close()
        {
        }

        #endregion

        void OnClosingClient(IClientAPI client)
        {
            client.OnUserReport -= UserReport;
        }

        void OnNewClient(IClientAPI client)
        {
            client.OnUserReport += UserReport;
        }

        /// <summary>
        ///     This deals with saving the report into the database.
        /// </summary>
        /// <param name="client"></param>
        /// <param name="regionName"></param>
        /// <param name="abuserID"></param>
        /// <param name="catagory"></param>
        /// <param name="checkflags"></param>
        /// <param name="details"></param>
        /// <param name="objectID"></param>
        /// <param name="position"></param>
        /// <param name="reportType"></param>
        /// <param name="screenshotID"></param>
        /// <param name="summery"></param>
        /// <param name="reporter"></param>
        void UserReport(IClientAPI client, string regionName, UUID abuserID, byte catagory, byte checkflags,
                                string details, UUID objectID, Vector3 position, byte reportType, UUID screenshotID,
                                string summery, UUID reporter)
        {
            AbuseReport report = new AbuseReport
                                     {
                                         ObjectUUID = objectID,
                                         ObjectPosition = position.ToString(),
                                         Active = true,
                                         Checked = false,
                                         Notes = "",
                                         AssignedTo = "No One",
                                         ScreenshotID = screenshotID
                                     };

            if (objectID != UUID.Zero) {
                ISceneChildEntity Object = client.Scene.GetSceneObjectPart(objectID);
                report.ObjectName = Object.Name;
            } else
                report.ObjectName = "";

            string[] detailssplit = details.Split('\n');

            string AbuseDetails = detailssplit[detailssplit.Length - 1];

            report.AbuseDetails = AbuseDetails;

            report.ReporterName = client.Name;

            string[] findRegion = summery.Split('|');
            report.RegionName = findRegion[1];

            string[] findLocation = summery.Split('(');
            string[] findLocationend = findLocation[1].Split(')');
            report.AbuseLocation = findLocationend[0];

            string[] findCategory = summery.Split('[');
            string[] findCategoryend = findCategory[1].Split(']');
            report.Category = findCategoryend[0];

            string[] findAbuserName = summery.Split('{');
            string[] findAbuserNameend = findAbuserName[1].Split('}');
            report.AbuserName = findAbuserNameend[0];

            string[] findSummary = summery.Split('\"');

            string abuseSummary = findSummary[1];
            if (findSummary.Length != 0)
            {
                abuseSummary = findSummary[1];
            }

            report.AbuseSummary = abuseSummary;


            report.Number = (-1);

            EstateSettings ES = client.Scene.RegionInfo.EstateSettings;
            //If the abuse email is set up and the email module is available, send the email
            if (ES.AbuseEmailToEstateOwner && ES.AbuseEmail != "")
            {
                IEmailModule Email = m_Scene.RequestModuleInterface<IEmailModule>();
                if (Email != null)
                {
                    string msg = "This abuse report was submitted by " +
                                 report.ReporterName + " against " +
                                 report.AbuserName + " at " +
                                 report.AbuseLocation + " in your region " +
                                 report.RegionName +
                                 ". Summary: " + report.AbuseSummary +
                                 ". Details: " + report.AbuseDetails + ".";
                
                    Email.SendEmail (
                        UUID.Zero,
                        ES.AbuseEmail,
                        "Abuse Report",
                        msg,
                        client.Scene
                    );
                }
            }
            //Tell the DB about it
            IAbuseReports conn = m_Scene.RequestModuleInterface<IAbuseReports>();
            if (conn != null)
                conn.AddAbuseReport(report);
        }

        #region Disabled CAPS code

        OSDMap OnRegisterCaps(UUID agentID, IHttpServer server)
        {
            OSDMap retVal = new OSDMap();
            retVal["SendUserReportWithScreenshot"] = CapsUtil.CreateCAPS("SendUserReportWithScreenshot", "");
            retVal["SendUserReport"] = retVal["SendUserReportWithScreenshot"];

            //Region Server bound
            server.AddStreamHandler(new GenericStreamHandler(
                "POST", retVal["SendUserReportWithScreenshot"],delegate(
                    string path, Stream request,OSHttpRequest httpRequest,OSHttpResponse httpResponse) {
                    return ProcessSendUserReportWithScreenshot(agentID, path, request, httpRequest,httpResponse);
                }
            ));

            return retVal;
        }

        byte[] ProcessSendUserReportWithScreenshot(UUID agentID, string path, Stream request,
                                                   OSHttpRequest httpRequest, OSHttpResponse httpResponse) 
        {
            IScenePresence SP = findScenePresence(agentID);
            OSDMap map = (OSDMap)OSDParser.DeserializeLLSDXml(HttpServerHandlerHelpers.ReadFully(request));
            //string RegionName = map["abuse-region-name"];

            UUID AbuserID = map["abuser-id"];
            uint Category = map["category"];
            uint CheckFlags = map["check-flags"];
            string details = map["details"];
            UUID objectID = map["object-id"];
            Vector3 position = map["position"];
            uint ReportType = map["report-type"];
            UUID ScreenShotID = map["screenshot-id"];
            string summary = map["summary"];

            UserReport(
                SP.ControllingClient,
                SP.Scene.RegionInfo.RegionName,
                AbuserID,
                (byte)Category,
                (byte)CheckFlags,
                details,
                objectID,
                position,
                (byte)ReportType,
                ScreenShotID,
                summary,
                SP.UUID
            );

            if (ScreenShotID != UUID.Zero)
            {
                string uploadpath = "/CAPS/Upload/" + UUID.Random() + "/";
                AbuseTextureUploader uploader = new AbuseTextureUploader(uploadpath, SP.UUID, ScreenShotID);
                uploader.OnUpLoad += AbuseTextureUploaded;

                MainServer.Instance.AddStreamHandler(new GenericStreamHandler("POST", uploadpath, uploader.uploaderCaps));

                string uploaderURL = MainServer.Instance.ServerURI + uploadpath;
                OSDMap resp = new OSDMap();
                resp["uploader"] = uploaderURL;
                resp["state"] = "upload";

                return OSDParser.SerializeLLSDXmlBytes(resp);
            }
           
            return MainServer.BlankResponse;
        }


        public delegate void UploadedAbuseTexture(UUID agentID, UUID assetID, byte[] data);

        public class AbuseTextureUploader
        {
            public event UploadedAbuseTexture OnUpLoad;
            UploadedAbuseTexture handlerUpLoad;
            readonly UUID m_agentID;
            readonly UUID m_assetID;

            readonly string uploaderPath = string.Empty;

            public AbuseTextureUploader(string path, UUID agentID, UUID assetID)
            {
                uploaderPath = path;
                m_agentID = agentID;
                m_assetID = assetID;
            }

            /// <summary>
            /// </summary>
            /// <param name="path"></param>
            /// <param name="request"></param>
            /// <param name="httpRequest"></param>
            /// <param name="httpResponse"></param>
            /// <returns></returns>
            public byte[] uploaderCaps(string path, Stream request,
                                       OSHttpRequest httpRequest, OSHttpResponse httpResponse)
            {
                handlerUpLoad = OnUpLoad;
                handlerUpLoad(m_agentID, m_assetID, HttpServerHandlerHelpers.ReadFully(request));

                OSDMap map = new OSDMap();
                map["new_asset"] = m_assetID.ToString();
                map["item_id"] = UUID.Zero;
                map["state"] = "complete";

                MainServer.Instance.RemoveStreamHandler("POST", uploaderPath);

                return OSDParser.SerializeLLSDXmlBytes(map);
            }
        }

        public void AbuseTextureUploaded(UUID agentID, UUID assetID, byte[] data)
        {
            //MainConsole.Instance.InfoFormat("[AssetCAPS]: Received baked texture {0}", assetID.ToString());
            AssetBase asset = new AssetBase(assetID, "Abuse Texture", AssetType.Texture, agentID) { Data = data };
            asset.ID = m_Scene.AssetService.Store(asset);
            MainConsole.Instance.DebugFormat("[AbuseCAPS]: texture new id {0}", assetID);
        }

        #endregion

        #region Helpers

        public IScenePresence findScenePresence(UUID avID)
        {
            return m_Scene.GetScenePresence(avID);
        }

        #endregion
    }
}
