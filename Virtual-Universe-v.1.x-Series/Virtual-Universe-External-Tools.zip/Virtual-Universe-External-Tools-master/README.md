# Virtual Universe External Tools

This repository contains tools that can be used to help make running Virtual Universe easier while enhancing the features that you can offer your users.

The tools provided in this repository are used by the Second Galaxy Development Team on our grid and region servers for Second Galaxy!



# Copyright and Ownership

The Virtual Universe Open Source Project, the name Virtual Universe, the Virtual Universe logos and marks are the exclusive property of the Second Galaxy Development Team.

Copyright 2016-2025 Second Galaxy Development Team ALL RIGHTS RESERVED!

# Contributing

Q: Have a tool you made to use with Virtual Universe and want to have it included?

A: You can fork this repository to your user account on Github and commit your tool.  Then simply submit a pull request to this repository.  Your contribution will be reviewed and upon approval added to the repository for all to use.
