# Ubuntu Directory

This contains installer tools for use on Ubuntu.  Tools are known to work with Ubuntu 14.04.4 LTS (Trusty Tahr) and Ubuntu 16.04 LTS (Xenial Xarus)