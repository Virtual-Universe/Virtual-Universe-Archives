# Installer Directory

This directory contains installers to help you get Virtual Universe set up on any operating system quickly.  Some interaction may be required.