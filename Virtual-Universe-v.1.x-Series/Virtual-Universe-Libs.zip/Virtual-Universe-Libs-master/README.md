# Virtual Universe Libraries

3rd party libraries used for Virtual Universe
Built as addon-modules

## Compiling
*To compile add these folders, or just an updated one, to the addon-modules folder of the main Virtual Universe repository.
 Execute the normal "runPreBuild" for your system and then build/compile as normal.
 The newly compiled library will be copied to the "bin" folder*

 Emperor Starfinder <emperor@secondgalaxy.com>
June 14, 2015