nant clean
