#!/bin/sh
prebuild /target xcode /file ../prebuild.xml /pause
