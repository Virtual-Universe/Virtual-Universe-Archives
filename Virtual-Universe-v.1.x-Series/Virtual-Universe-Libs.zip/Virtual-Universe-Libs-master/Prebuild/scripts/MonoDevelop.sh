#!/bin/sh
prebuild /target monodev /file ../prebuild.xml /build NET_1_1 /pause
