#!/bin/sh
prebuild /target nant /file ../prebuild.xml /pause
