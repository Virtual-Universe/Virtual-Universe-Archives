#!/bin/sh

./prebuild /clean /removedir obj /file ../prebuild.xml /pause
rm -rf ../Makefile
