#!/bin/sh
#exec mono [PREFIX]/prebuild.exe "$@"
exec mono Prebuild.exe /target VS2010 
