There are some tests that are run via a Makfile in this
directory. They haven't been included in any form of unit tests, but
they are there to help test the functionality in some what. Simply
build prebuild (so there is a src/bin/Release/prebuild.exe) and type
`make` in this directory. Everything should pass without errors.
