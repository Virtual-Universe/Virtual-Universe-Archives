| Q             | A
| ------------- | ---
| Bug fix?      | [yes|no]
| New feature?  | [yes|no]
| Deprecations? | [yes|no]
| Fixed tickets | [comma separated list of tickets fixed by the PR]
